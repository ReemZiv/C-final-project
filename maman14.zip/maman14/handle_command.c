//This file contains functions to handle each command, and analyze the operands according to the opcode, finds some errors and builds the binary code of the instructions array and the data array.

#include "assembler.h"

extern int is_error, line_cnt;


//This function handles the .extern command. it gets the operands of the command in a string called operand.
void handle_extern(char *operand){
	//initializations
	char *word, *tmp;
	char *val[LINE_MAX]; //val will hold all the labels in the extern command because we wanna check it's syntax and then add it to the symbols table
	int i = 0;
	
	while((word = strtok_r(operand,",",&operand)) != NULL){//going on every operand by splitting the string by commas
		word = remove_inspaces(word);
		if(check_extra(word)){ //checking for extra text or missing comma possibly in every operand of extern
			tmp = (check_space_type(word) == '\t') ? strtok_r(word,"\t",&word) : strtok_r(word," ",&word);
			if((find_par(tmp) == DIRECT_ADDRESS) && (find_par(word) == DIRECT_ADDRESS)) //if both operands are labels that means a comma is missing, else it is extra text
				printf("[line %d] ERROR: missing comma\n",line_cnt);
			else
				printf("[line %d] ERROR: extra text in operand of .data\n",line_cnt);
			return;
		}
		if(find_par(word) == DIRECT_ADDRESS){ //checking if the operand is a label
			remove_spaces(word);
			val[i++] = word;
		}
		else{ //if the operand isn't a label
			printf("[line %d] ERROR: .extern operands must be labels\n",line_cnt);
			is_error = 1;
			return;
		}	
	}
	
	for(int j=0; j < i; j++) //adding every label to the symbols code
		insert_sym(val[j],0,external);
}


//This function handles the .data command. it gets the operands of the command in a string called operand and DC - data count.
int handle_data(char *operand, int DC){
	//initializations
	char *word,*tmp;
	int num, tmp_num,val[LINE_MAX], i=0; //val will hold all the integers in the .data command because we wanna check it's syntax and then add it to the data array
	
	operand = remove_inspaces(operand); 
	
	while((word = strtok_r(operand,",",&operand)) != NULL){ //going on every operand by splitting the string by commas
		operand = remove_inspaces(operand); 
		if(check_extra(word)){ //checking for extra text or missing comma possibly in every operand
			tmp = strtok_r(word," ",&word);
			if(((num = atoi(tmp)) != 0 || strcmp(tmp,"0") == 0) && ((num = atoi(word)) != 0 || strcmp(word,"0") == 0)) //if both operands are integers that means a comma is missing, else it is extra text
				printf("[line %d] ERROR: missing comma\n",line_cnt);
			else
				printf("[line %d] ERROR: extra text in operand of .data\n",line_cnt);
			return DC;
		}
		if(atof(word) != (double)(atoi(word))){ //checking if a float was entered
			is_error = 1;
			printf("[line %d] ERROR: .data operands must be integers\n",line_cnt);
			return DC;
		}
		
		remove_spaces(word);
		if((num = atoi(word)) != 0 || strcmp(word,"0") == 0){ //checking if integers were inserted
			if(num < 0){ //if number is negative we need to use bin_nset so we get only 12-bits representation in int
				tmp_num = 0;
				tmp_num = bin_nset(tmp_num,num,0);
				val[i++] = tmp_num;
			}
			else val[i++] = num; 
		}
		else{ //if it isn't an integer
			printf("[line %d] ERROR: .data operands must be integers\n",line_cnt);
			is_error = 1;
			return DC;
		}
	}
	
	for(int j=0; j<i; j++) //adding the numbers binary code to the data array
		insert_data(val[j],DC++);
	return DC;
}

//This function handles the .string command. It gets the operand of the command and DC - data count
int handle_string(char *operand, int DC){
	remove_spaces(operand); //removing spaces so it will be easier to check it's syntax
	
	if(*operand != '"' || operand[strlen(operand)-1] != '"'){ //checking the string starts and ends with quotation marks
		printf("[line %d] ERROR: .string operand must start and end with quotation marks\n",line_cnt);
		is_error = 1;
		return DC;
	}
	
	for(int i = 1; i < strlen(operand) - 1; i++){ //inserting each character ASCII code to the data array
		insert_data(operand[i],DC++);
	}
	
	insert_data(0,DC++); //Finally, inserting 0 to the data array to sign the end of the string
	return DC;
}

//This function gets the attributes of a line, checks it's syntax validity and updating the binary code accordingly. It gets an integer that represents the code of the opcode, the opcode itself as an AST, count of operands as an int and IC - instructions count.
void handle_op(int op_int, AST *opcode, int par_cnt, int IC){ 
	int binary_code = 0, par1_code, par2_code ,par_binary = 0; //initializations
	
	binary_code = bin_nset(binary_code,op_int,OP_INDEX); //starting to code the first word(first binary code) by applying the code of the opcodein the correct place
	switch(par_cnt){
		case 0:
			insert_inst(binary_code, IC++); //If there are no parameters there is no need for other words or to update the first word because there are no operands so we insert it to the instructions array
			break;
		case TWO_PAR:
			//checking validity of operands type and building the operands code in the first word
			if((par2_code = find_par(opcode->data.OPCODE.operand_2->data.op2)) == MISSING) break; 
			if((par1_code = find_par(opcode->data.OPCODE.operand_1->data.op1)) == MISSING) break;
			
			//checking validity of operand's type to the opcode
			if(check_par(op_int,par_cnt,par1_code,par2_code) == MISSING){
				printf("[line %d] ERROR: first operand is of type %s which is illegal for %s opcode\n",line_cnt,num_to_type(par1_code),opcode->data.OPCODE.opcode);
				is_error = 1;
				break;
			}
			
			else if(check_par(op_int,par_cnt,par1_code,par2_code) == OP2_MISSING){
				printf("[line %d] ERROR: second operand is of type %s which is illegal for %s opcode\n",line_cnt,num_to_type(par2_code),opcode->data.OPCODE.opcode);
				is_error = 1;
				break;
			}
			
			binary_code = bin_nset(binary_code,par2_code,DES_INDEX); //applying code of the second operand in the first word in the destination place
			par_binary = handle_par(par_binary,par2_code,opcode->data.OPCODE.operand_2->data.op2,DES_REG_INDEX); //building binary code of second operand
			if(par2_code == REG_ADDRESS && par1_code  == REG_ADDRESS){ //if both operands are registeres we combine both of their binary codes to one binary code
				binary_code = bin_nset(binary_code,par1_code,SOURCE_INDEX); //applying code of the first operand in the first word in the source place
				insert_inst(binary_code, IC++); //inserting the binary code of the first word to the instructions array
				insert_inst(handle_par(par_binary,par1_code,opcode->data.OPCODE.operand_1->data.op1,SOURCE_REG_INDEX),IC++); //building the first operand binary code and inserting it to the instructions array
				break;
			}
			binary_code = bin_nset(binary_code,par1_code,SOURCE_INDEX); //applying code of the first operand in the first word in the correct place
			insert_inst(binary_code, IC++); //inserting the binary code of the first word to the instructions array
			insert_inst(handle_par(0,par1_code,opcode->data.OPCODE.operand_1->data.op1,SOURCE_REG_INDEX),IC++); //building the first operand binary code and inserting it to the instructions array 
			insert_inst(par_binary, IC++); //inserting the binary code of the second operand to the instructions array
			break;
		case 1:
			if((par1_code = find_par(opcode->data.OPCODE.operand_1->data.op1)) == MISSING) break; //checking validity of the operand
			if(check_par(op_int,par_cnt,par1_code,par2_code) == MISSING){ //checking validity of operand's type to the opcode
				printf("[line %d] ERROR: first operand is of type %s which is illegal for %s opcode\n",line_cnt,num_to_type(par1_code),opcode->data.OPCODE.opcode);
				is_error = 1;
				break;
			}
			binary_code = bin_nset(binary_code,par1_code,DES_INDEX); //applying code of the operand in the first word in the destination place 
			insert_inst(binary_code, IC++); //inserting the binary code of the first word to the instructions array
			insert_inst(handle_par(par_binary,par1_code,opcode->data.OPCODE.operand_1->data.op1,DES_REG_INDEX),IC++); //building the first operand binary code and inserting it to the instructions array 
			break;
	}
}

//This function checks the validity of labels entered as operands and completes their binary code. It gets the AST of the line, the AST node of the opcode, count of operands as an int, and IC - instructions count.
void complete_op(AST *tree, AST *opcode, int par_cnt, int IC){
	int binary_code = 0, par_code, sym_value = 0; //initializations
	
	switch(par_cnt){
		case 0: //If there are no operands there's nothing to check or complete
			break;
		case TWO_PAR: //If there are two operands
			par_code = find_par(opcode->data.OPCODE.operand_2->data.op2); //finding type of second operand
			if(par_code == DIRECT_ADDRESS){ //if second operand is a label
				if(tree->tag == LABEL && strcmp(tree->data.LABEL.label,opcode->data.OPCODE.operand_2->data.op2) == 0){ //checking if there was declaraed a label that is used as an operand in the same line
					printf("[line %d] ERROR: a label can't be used as an operand the same line it is defined\n",line_cnt);
					is_error = 1;
					return;
				}
				sym_value = find_sym(opcode->data.OPCODE.operand_2->data.op2); //getting the value of the label from the symbols table
				if(sym_value == 1){ //if it's an external label
					binary_code = 1; //binary code of external labels equals to 1 in decimal base
					insert_extern(opcode->data.OPCODE.operand_2->data.op2,IC+TWO_PAR); //inserting this appearance of this external label to the external labels appearances dynamic list 
				}
				else{ //if it isn't an external label
					binary_code = bin_nset(binary_code,RELOCATABLE,0); //changing the binary code ARE to 10(in binary base) because it's a label 
					binary_code = bin_nset(binary_code,sym_value,RELOCATABLE); //applying the binary code of the label value in the operand's binary code
				}
				change_inst(binary_code,IC+TWO_PAR); //changing the binary code of the second operand to the new completed binary code
			}
		case 1:
			par_code = find_par(opcode->data.OPCODE.operand_1->data.op1); //finding type of first operand
			if(par_code == DIRECT_ADDRESS){ //if first operand is a label
				if(tree->tag == LABEL && strcmp(tree->data.LABEL.label,opcode->data.OPCODE.operand_1->data.op1) == 0){ //checking if there was declaraed a label that is used as an operand in the same line
					printf("[line %d] ERROR: a label can't be used as an operand the same line it is defined\n",line_cnt);
					is_error = 1;
					return;
				}
				sym_value = find_sym(opcode->data.OPCODE.operand_1->data.op1); //getting the value of the label from the symbols table
				if(sym_value == 1){ //if it's an external label
					binary_code = 1; //binary code of external labels equals to 1 in decimal base
					insert_extern(opcode->data.OPCODE.operand_1->data.op1,IC+1); //inserting this appearance of this external label to the external labels appearances dynamic list 
				}
				else{
					binary_code = bin_nset(binary_code,RELOCATABLE,0); //changing the binary code ARE to 10(in binary base) because it's a label 
					binary_code = bin_nset(binary_code,sym_value,RELOCATABLE); //applying the binary code of the label value in the operand's binary code
				}
				change_inst(binary_code,IC+1); //changing the binary code of the first operand to the new completed binary code
			}
			break;
	}
	return;
}
