//This file contains the first go of the asssembler. In the first go, it analyzes the input and indicating errors, it completes the symbols table and it starts to build the binary code(only of immediate address and registers)

#include "assembler.h" 
int IC=0, DC=0, L=0; //initializing IC(instructions count),DC(data count) and L - count of binary codes the line takes
int line_cnt, is_error,is_all_error; //line_cnt - the number of the line the function is at(first line is 1), is_error -indicates if there was an error in the line the function is currently at, is_all_error - indicates if there was an error in the whole file
char *error_arr; //error_arr = array of characteres(only 0 and 1), to indicate in which lines there are errors(the index of the character is the number of the line, for example if line 7 had an error then error_arr[7] will be 1)

void first_go(FILE *as){
	memory_map(); //initializes the memory map
	symbols_table(); //initializes the symbols table
	
	//initializes
	error_arr = (char *) malloc(LINE_MAX);
	char *line = (char *)(malloc(BIGGER_THAN_LINE_MAX));
	char *tmp;
	AST *tree, *op_node, *par_node; //tree - abstract syntax tree to hold each line attributes(label,opcode,operand1,operand2), op_node - node of the opcode, par_node - node of the first operand
	int is_sym; //indicates if a symbol was defined
	int op_int, par_cnt, par_cnt_input=0; //op_int - the decimal code of an opcode, par_cnt - how many parameters should the opcode have, par_cnt_input - how many parameters were entered
	DC = 0; IC = 0; line_cnt = 0; is_all_error = 0;
	
	while(fgets(line,BIGGER_THAN_LINE_MAX,as) != NULL){ //going through each line
		L = 0, is_sym = 0, is_error = 0;
		line_cnt++;
		if(strlen(line) > ((line[strlen(line)-1] == '\n') ? LINE_MAX : LINE_MAX-1)){ //checking length of the line is valid
			printf("[line %d] ERROR: maximum length of a line is %d!\n",line_cnt,LINE_MAX-1);
			handle_error(error_arr,tree);
			continue;
		}
		
		tmp = strdup(line);
		tmp = remove_inspaces(tmp); //removing all initial spaces
		if(is_empty(tmp) || tmp[0] == ';') //if it's an empty line or a comment line
			continue;

		tree = analyze_input(tmp,tree); // splitting the line to its attributes and creating an abstract syntax tree of the line;
		if(tree->tag == LABEL) //If there was a label defined we indicate it and assigns op_node to its place
			is_sym = 1;
		op_node = tree->data.LABEL.opcode;
		par_node = op_node->data.OPCODE.operand_1; //assigning par_node to the first operand
		par_cnt_input = count_input_par(par_node,op_node->data.OPCODE.operand_2); //checking how many operands were inserted
		
		if(is_error == 1){ //If there was an error in the analyze of the line we handle it and move to the next line
			error_arr = handle_error(error_arr,tree);
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
			continue;
		}
	
		if(strcmp(op_node->data.OPCODE.opcode,".data") == 0 || strcmp(op_node->data.OPCODE.opcode,".string") == 0){ //checking if it's data or string command
				if(par_cnt_input == 1){ //if one operand was inserted(as it should)
					if(is_sym == 1){ //if there's a label it's inserting the label to the symbols table
						insert_sym(tree->data.LABEL.label,DC,data);
					}
			
					if(strcmp(op_node->data.OPCODE.opcode,".data") == 0){ //if it's .data command it handles it
						DC = handle_data(par_node->data.op1,DC);
					}
			
					else if (strcmp(op_node->data.OPCODE.opcode,".string") == 0){// if it's .string command it handles it
						DC = handle_string(par_node->data.op1,DC);
					}
					
					if(is_error)
						handle_error(error_arr,tree);
					free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
					continue;
				}
				else{ //if not one operand was inserted
					is_error = 1;
					printf("[line %d] ERROR: wrong count of operands! %s opcode should have 1 operands, yet %d operands were entered.\n",line_cnt,op_node->data.OPCODE.opcode,par_cnt_input);
					if(is_error)
						handle_error(error_arr,tree);
					free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
					continue;
				}
		}
		
		else if(strcmp(op_node->data.OPCODE.opcode,".extern") == 0 || strcmp(op_node->data.OPCODE.opcode,".entry") == 0){ //if it's an .extern or .entry command
			if(strcmp(op_node->data.OPCODE.opcode,".extern") == 0) //if it's an .extern command it handles it
				handle_extern(par_node->data.op1);
			else //it it's an .entry command it checks the validity of the label
				check_label(par_node->data.op1);
			if(is_error) handle_error(error_arr,tree);
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
			continue;
		}
		
		if(is_sym == 1){//if a symbol was defined we try to insert it to the symbols table 
			insert_sym(tree->data.LABEL.label,IC,code);
		}
		
		if(is_error == 0){ //if no error was found
			if((op_int  = find_op(op_node->data.OPCODE.opcode)) != MISSING){ //if opcode is valid
				par_cnt = count_par(op_int); //checking how many operands the opcode should have
				if(par_cnt != par_cnt_input){ //if the count of operands inserted is different  than the count of operands the opcode should have it's an error
					is_error = 1;
					printf("[line %d] ERROR: wrong count of operands! %s opcode should have %d operands, yet %d operands were entered.\n", line_cnt, op_node->data.OPCODE.opcode,par_cnt,par_cnt_input);
				}
				else
					handle_op(op_int,op_node,par_cnt,IC); //handling the opcode
			}
			else{ //if opcode isn't valid
				par_cnt = par_cnt_input;
				is_error = 1;
				printf("[line %d] ERROR: opcode isn't valid\n", line_cnt);
			}
		}
		
		//changing L
		if(par_cnt == TWO_PAR && find_par(par_node->data.op1) == REG_ADDRESS && find_par(op_node->data.OPCODE.operand_2->data.op2) == REG_ADDRESS){ //if both operands are registeres we put them both in one binary code
			L += par_cnt;
		}
		else{
			L += par_cnt + 1;
		}
		
		
		//if no error was fund
		if(is_error == 0){
			error_arr[line_cnt] = '0';
			IC += L;
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
		}
		
		//if error was found
		else{
			handle_error(error_arr,tree);
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
			continue;
		}
	
	}
	
	update_sym(IC); //updating all data symbols
}	
