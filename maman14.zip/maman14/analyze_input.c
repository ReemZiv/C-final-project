//jThis file contain the analyze of the input to its different attributes, finding some errors and making an AST contains every attribute.
#include "assembler.h"

extern int is_error, line_cnt;


//This function splittes the line into its different attributes(label,opcode,operand1,operand2) and creating an abstract syntax tree of this line.It gets a string(line) as a parameter for the line, and an AST called tree as a parameter for the abstract syntax tree
AST *analyze_input(char *line, AST *tree){
	//initializations
	char *word;
	AST *op_node, *par1_node, *par2_node;
	int is_sym = 0;
	
	tree = (AST *) malloc(sizeof(AST));
	tree->tag = MISSING;
	
	//copying the line to line
	line = remove_inspaces(line);
	
	//allocating memory to all tree atributes
	tree->data.LABEL.opcode = (AST *) malloc(sizeof(AST));
	tree->data.LABEL.opcode->data.OPCODE.operand_1 = (AST *) malloc(sizeof(AST));
	tree->data.LABEL.opcode->data.OPCODE.operand_2 = (AST *) malloc(sizeof(AST));
	
	op_node = tree->data.LABEL.opcode;
	par1_node = tree->data.LABEL.opcode->data.OPCODE.operand_1;
	par2_node = tree->data.LABEL.opcode->data.OPCODE.operand_2;
	
	//checking if a label is defined
	word = (check_space_type(line) == '\t') ? strtok_r(line,"\t",&line) : strtok_r(line," ",&line);
	if(word[strlen(word)-1] == ':'){
		if(check_label(word) == 0)
			return tree; 																																																									
		is_sym = 1;
		tree->tag = LABEL;
		tree->data.LABEL.label = strtok_r(word,":",&word);
		line = remove_inspaces(line);
		if(is_empty(line)){ //checking an opcode was entered
			printf("[line %d] ERROR: missing opcode\n",line_cnt);
			is_error = 1;
			return tree;
		}	
		word = (check_space_type(line) == '\t') ? strtok_r(line,"\t",&line) : strtok_r(line," ",&line); //splitting the line again in the next space in order for word to be the opcode
	}
	
	remove_spaces(word);
	line = remove_inspaces(line);
	
	if(line[0] == ':'){ //checking if the colon isn't attached to the label
		printf("[line %d] ERROR: colon must be attached to the end of the label\n",line_cnt);
		is_error = 1;
		return tree;
	}
	if(line[0] == ','){ //checking if the first operand is empty
		printf("[line %d] ERROR: empty operand\n",line_cnt);
		is_error = 1;
		return tree;
	}
	if(check_illegal_comma(word)){ //checking for an illegal comma at the end of the opcode
		printf("[line %d] ERROR: illegal comma after end of opcode\n",line_cnt);	
		is_error = 1;
		return tree; 
	}
	
	//assigns the opcode to op_node
	op_node->tag = OPCODE;
	op_node->data.OPCODE.opcode = word;
	
	if(is_empty(line) == 0){ //checking if there are operands
		if(strcmp(op_node->data.OPCODE.opcode, ".data") != 0 && strcmp(op_node->data.OPCODE.opcode, ".extern") != 0){ //checking if it's not .data or .extern (that can have multiple operands)
			line = remove_inspaces(line);
			if(check_illegal_comma(line)){ //checking for an illegal comma at the end of the second operand
				printf("[line %d] ERROR: illegal comma after end of operand\n",line_cnt);			
				return tree; 
			}
			word = strtok_r(line,",",&line);
			if(check_extra(word)){ //checking for extra text
				if(count_par(find_op(op_node->data.OPCODE.opcode)) == TWO_PAR){ //checking for extra text might be true if there's missing comma
					printf("[line %d] ERROR: missing comma, %s opcode expects for two operands\n",line_cnt,op_node->data.OPCODE.opcode);
					return tree;
				}
				
				if(check_missing_colon(word,op_node->data.OPCODE.opcode)) return tree; //checking if there was missing a colon in the label and the program took it as a command name
				printf("[line %d] ERROR: extra text after end of first operand\n",line_cnt); //if NONE of the options above was true it means that there is extra text
				return tree;
			}
			
		}
		else{ //if it's a .data or .extern we copy the whole line to the operand since it has multiple operands
			word = (char *) malloc(strlen(line)+1);
			strcpy(word,line);
			*line = '\0';								
		}
		
		if(strcmp(op_node->data.OPCODE.opcode, ".data") != 0 && strcmp(op_node->data.OPCODE.opcode, ".extern") != 0) remove_spaces(word); //we remove spaces for easier syntax analyze, yet we can't do it in data an extern because they can have multiple operands
		//initialize the first operand in the AST
		par1_node->tag = OPERAND_1; 
		par1_node->data.op1 = word;
		if(is_empty(line) == 0){ //checking if there is a second operand
			if(check_extra(line)){ //checking for extra text in the end of the second operand
				printf("[line %d] ERROR: extra text after end of second operand\n",line_cnt);
				is_error = 1;
				return tree;
			}
			remove_spaces(line);
			if(line[0] == ','){ //checking for multiple consecutive commas by checking if the first character is a comma
				printf("[line %d] ERROR: Multiple consecutive commas\n",line_cnt);
				is_error = 1;
				return tree;
			}
			if(word[strlen(word)-1] == ','){ //checking for an illegal comma in the end of the operand
				printf("[line %d] ERROR: illegal comma after end of second operand\n",line_cnt);
				is_error = 1;
				return tree;
			}
			//second operand is valid so we initialize the second operand in the AST
			par2_node->tag = OPERAND_2;
			par2_node->data.op2 = line;
		}
	}
	return tree;
}
