//This file contains the symbols_table and its functions which runs different actions on the symbols table - linked dynamic list that contains every symbol in the assembly file, its value, its type in decimal base and a pointer to the next symbol. This file also includes a linked dynamic list of every appearance in the assembly file of the extern labels.
#include "assembler.h"

//global variables
sym_tab *first, *cur; //first - the first symbol, cur - the current symbol the function is at
sym_tab *first_extern, *cur_extern; //first_extern - the first apperance of an extern label, cur_extern - the current apperance of an extern label the function is at
extern int line_cnt, is_error;

//This function initializes the symbols table and the extern apperances table.
void symbols_table(){
	first = (sym_tab *) malloc(sizeof(sym_tab));
	cur = first;
	first->next = NULL;
	first_extern = (sym_tab *) malloc(sizeof(sym_tab));
	cur_extern = first_extern;
	first_extern->next = NULL;
}

//This next function is inserting a symbol to the symbols table which is represented using a linked list. It checks if the symbol already exists in the symbols table, if it is, returns an error, if not, inserting it to the symbols table.
void insert_sym(char *name, int value, int type){

	//Initalizations 
	sym_tab *tmp;
	tmp = first;
	
	if(strlen(name) > LABEL_MAX_LEN){ //checking validity of the label name length
		printf("[line %d] ERROR: maximum length of a label name is 31\n",line_cnt);
		is_error = 1;
		return;
	}
	
	while(tmp->next != NULL){ //Going through every symbol to check if the symbol already exists in the symbols table
		if(strcmp(tmp->symbol,name) == 0){
			printf("[line %d] ERROR: Symbol already exists!!!\n", line_cnt);
			is_error = 1;
			return;
		}
		tmp = tmp->next; 
	}
	
	//This lines inserting the values to the current node, creating a new symbol node, asserting it to the next value of the current node, and setting the current node to be the new symbol node which is currently NULL
	tmp = (sym_tab *) (malloc(sizeof(sym_tab)));
	cur->symbol = (char *) (malloc(strlen(name) + 1));
	strcpy(cur->symbol, name);
	cur->value = (type == external) ? value : value + FIRST_ADDRESS;
	cur->type = type;
	cur->next = tmp;
	cur = cur->next;
}

//This function inserts an appearance of an extern label to the extern table. It gets the name of the label, and the value which represents the address(in decimal base) the extern was appeared
void insert_extern(char *name, int value){
	sym_tab *tmp;
	tmp = (sym_tab *) (malloc(sizeof(sym_tab))); 
	cur_extern->symbol = (char *)malloc(strlen(name) + 1);
	strcpy(cur_extern->symbol,name);
	cur_extern->value = value + FIRST_ADDRESS;
	cur_extern->next = tmp;
	cur_extern = cur_extern->next;
}

//This funcction updates all the data symbols values by adding IC to them. It gets IC as a parameter
void update_sym(int IC){
	sym_tab *tmp;
	tmp = first;
	
	while(tmp->next != NULL){ //going through every symbol
		if(tmp->type == data){//checking if its a data symbol
			tmp->value += IC; //updating the value
		}
		tmp = tmp->next;
	}
}

//This function updates a type of a specific symbol to entry. It gets the name of the symbol we want to change its type as a parameter
void update_entry(char *name){
	int is_symbol_exist = 0;
	sym_tab *tmp;
	tmp = first;
	
	while(tmp->next != NULL){ //going through every symbol name
		if(strcmp(tmp->symbol,name) == 0){ //checking if it found the symbol it's looking for
			if(tmp->type == external){ //checking if this symbol was defined as external which is an error because a label can't be defined both as entry and extern
				printf("[line %d] ERROR: a label can't be defined both as extern and entry\n",line_cnt);
				is_error = 1;
				return;
			}
			is_symbol_exist = 1; //signs that it found the symbol
			tmp->type = entry; //changing its type to entry
			break;
		}
		tmp = tmp->next;
	}
	
	if(first->next == NULL || is_symbol_exist == 0){ //if symbols table is empty or the function didn't find the symbol, it's an error
		printf("[line %d] ERROR: The label entered as operand of .entry doesn't exist\n",line_cnt);
		is_error = 1;
		return;
	}
}

//This function is updating the symbol's value to 0 if an error was found in the same line the symbol was defined. It gets the name of the symbol we want to change its value as a parameter
void update_error(char *name){
	sym_tab *tmp;
	tmp = first;
	while(tmp->next != NULL){ //going through every symbol
		if(strcmp(tmp->symbol,name) == 0) //checking if we found the symbol
			tmp->value = 0; //updating the symbol's value to 0
		tmp = tmp->next;
	}
}

//This function finds a specific symbol by its name and returns its value. It gets the name of the symbol as a parameter and returns the symbol's value
int find_sym(char *name){
	sym_tab *tmp;
	tmp = first;
	
	while(tmp->next != NULL){ //going through every symbol
		if(strcmp(tmp->symbol,name) == 0){ //checking if we found the symbol
			if(tmp->type == external) //if it's an extern label we return 1 to indicate it's external
				return 1;
			return tmp->value; //returning the value
		}
		tmp = tmp->next;
	}
	
	//If the program didn't find the symbol it's an error
	printf("[line %d] ERROR: the symbol entered as an operand doesn't exist\n",line_cnt);
	is_error = 1;
	return MISSING; //returns MISSING (-1) if the symbol doesn't exist
}

//This function creates the externs(.ext) file which contains every appearance of an extern label. It gets the name of the file as a parameter
void create_extern(char *name){
	int is_extern = 0;
	char new_name[FILE_NAME_MAX];
	FILE *file_ext;
	
	//creating the name of the file
	strcpy(new_name,name);
	strcat(new_name,".ext");

    sym_tab *temp1 = first_extern;
    while (temp1->next != NULL) { //going through every extern appearance
    	if(is_extern == 0){ //If it's the first extern appearance it creates the .ext file in order to not create the file if there aren't appearances of extern labels
    		file_ext = fopen(new_name, "w"); // Open the file in write mode
    		if (!file_ext) { // Checking if the file was opened successfully
        		printf("Error: Failed to open externals file for writing.\n");
        		return;
    		}
    		is_extern = 1; //indicating the file was created
    	}
        fprintf(file_ext, "%s %d\n", temp1->symbol, temp1->value); //Writing the symbol's name and it's value(in decimal base) to the file
        temp1 = temp1->next;
    }
    if(is_extern) fclose(file_ext);
}

//This function creates the entries(.ent) file which contains all the labels that were defined as entry. It gets the name of the file as a parameter 
void create_entry(char *name){
	FILE *file_ent;
	int is_entry = 0;
	char new_name[FILE_NAME_MAX];
	
	//creating the name of the file
	strcpy(new_name,name);
	strcat(new_name,".ent");

    sym_tab *temp2 = first;
    while (temp2->next != NULL) { //going through every symbol
        if (temp2->type == entry) {
        	if(is_entry == 0){
				file_ent = fopen(new_name, "w"); // Open the file in write mode ("w")
				if (!file_ent) { // Check if the file was opened successfully
		    		printf("Error: Failed to open entries file for writing.\n");
		    		return;
    			}
    			is_entry = 1; //indicating the file was created
    		}
            fprintf(file_ent, "%s %d\n", temp2->symbol, temp2->value); //Writing the symbol's name and it's value(in decimal base) to the file
        }
        temp2 = temp2->next;
    }
    if(is_entry) fclose(file_ent);
}

void free_sym(){
	sym_tab *temp1=first,*temp2=first_extern,*cur_sym;
    while (temp1->next != NULL) { //going through every symbol
        cur_sym = temp1;
        temp1 = temp1->next;
        free(cur_sym->symbol);
        free(cur_sym);
    }
	free(temp1);
	
    while (temp2->next != NULL) { //going through every symbol
        cur_sym = temp2;
        temp2 = temp2->next;
        free(cur_sym->symbol);
        free(cur_sym);
    }
    free(temp2);
}
    
