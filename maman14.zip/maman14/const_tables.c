#include "assembler.h"

int type_operands[OPCODES_WITH_PARS_CNT][SOURCE_AND_DEST_OPERANDS][MAX_TYPE_OPERANDS] = {{{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS}},{{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS},{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS}},{{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS}},{{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS}},{DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS},{{DIRECT_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS}},{DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS},{IM_ADDRESS,DIRECT_ADDRESS,REG_ADDRESS},{DIRECT_ADDRESS,REG_ADDRESS}};

char *op_code[OP_COUNT] = {"mov", "cmp", "add", "sub", "not", "clr", "lea", "inc", "dec", "jmp", "bne", "red", "prn", "jsr", "rts", "stop"}; 

int find_op(char *opcode){
	for(int i = 0; i < OP_COUNT; i++){
		if(strcmp(opcode,op_code[i])  == 0)
			return i;
	}
	return MISSING;
}

int check_par(int opcode, int cnt_par, int type_par1, int type_par2){
	switch(cnt_par){
		case TWO_PAR:
			if(check_element(type_operands[opcode][0],type_par1) == 0) 
				return MISSING;
			if(check_element(type_operands[opcode][1],type_par2) == 0)
				return OP2_MISSING;
		case 1:
			if(check_element(type_operands[opcode][0],type_par1) == 0) 
				return MISSING;
			return 1;
	}
}			
		
int check_element(int *arr, int element){
	for(int i = 0; i < MAX_TYPE_OPERANDS; i++){
		if(arr[i] == element)
			return 1;
	}
	return 0;
}
