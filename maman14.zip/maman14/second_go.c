//This file includes the second go of the assembler which completes the binary code of the file and creates the output files(object,extern and entry)
#include "assembler.h"

extern int IC,DC,L;
extern int line_cnt, is_error,is_all_error;
extern char *error_arr;

void second_go(FILE *as,char *file_name){
	//initializations
	char *line = (char *)(malloc(LINE_MAX));
	char *tmp;
	AST *tree, *op_node, *par_node;
	int IC=0, L=0;
	int op_int, par_cnt;
	line_cnt=0;
	
	while(fgets(line,BIGGER_THAN_LINE_MAX,as) != NULL){ //going through each line
		line_cnt++;
		if(error_arr[line_cnt] == '1') //if there was indicated an error in this line in the first go we skip it
			continue;
		
		tmp = strdup(line);
		tmp = remove_inspaces(tmp); //removing all initial spaces
		if(is_empty(tmp) || tmp[0] == ';') //if it's an empty line or a comment line
			continue;
			
		L = 0;
		tree = analyze_input(tmp,tree); //analyzing the input
		op_node = tree->data.LABEL.opcode;
		par_node = op_node->data.OPCODE.operand_1;
		
		if(strcmp(op_node->data.OPCODE.opcode,".extern") == 0 || strcmp(op_node->data.OPCODE.opcode,".string") == 0 || strcmp(op_node->data.OPCODE.opcode,".data") == 0){ //if it's an .extern, .string or .data command we skip it
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
			continue;
		}
		
		if(strcmp(op_node->data.OPCODE.opcode,".entry") == 0){ //if it's an .entry command we assign the label in the symbols table as an entry
			update_entry(par_node->data.op1);
			if(is_error)
				is_all_error = 1;
			free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
			continue;
		}
	
		//completing the binary code
		op_int  = find_op(op_node->data.OPCODE.opcode);
		par_cnt = count_par(op_int);
		complete_op(tree,op_node,par_cnt,IC);
		
		//calculating L
		if(par_cnt == TWO_PAR && find_par(par_node->data.op1) == REG_ADDRESS && find_par(op_node->data.OPCODE.operand_2->data.op2) == REG_ADDRESS){
			L += par_cnt;
		}
		else{
			L += par_cnt + 1;
		}
		
		IC += L; //updating IC - adding L to the IC
		
		
		//if error was found
		if(is_error){
			if(tree->tag == LABEL) update_error(tree->data.LABEL.label);
			is_all_error = 1;
		}

		free_memory(tree,op_node,par_node,op_node->data.OPCODE.operand_2);
	}

	if(is_all_error == 0){//if no errors were found we create the output files(if there aren't entry labels or extern apperances the functions know to not create the according file)
		create_object(file_name,IC, DC);
		create_extern(file_name);
		create_entry(file_name);
	}
	
	free_memory_map();
	free_sym();
}
