//This file contains different functions that check syntax errors in the file like validity of label and extra text.
#include "assembler.h"

extern int is_error, line_cnt;

//This function checks the validity of a label. It gets the label as a parameter and returns 1 if it's valid, or 0 else.
int check_label(char *label){
	label = remove_inspaces(label); //removing initial spaces
	if(label[0] == ':'){
		printf("[line %d] ERROR: label definition is empty\n",line_cnt);
		is_error = 1;
		return 0;
	}
	
	for(int i = 0;i < strlen(label); i++){
		if(!isdigit(*(label + i)) && !isalpha(*(label + i)) && *(label + i) != '\n'){ //checking if a character isn't alphabetical or a number
			if(*(label + i) == ':' && strlen(label) - 1 == i) //checking if it's the ':' in the end of the label
				break;
			printf("[line %d] ERROR: label must be consist ONLY of alphabetical letters and numbers\n",line_cnt);
			is_error = 1;
			return 0;
		}
	}
	return 1;
}

//This function checks if there's extra text in a specific line. It gets the line as a parameter and returns 1 if there's extra text, or 0 else
int check_extra(char *line){
	char *word, *tmp;
	tmp = strdup(line); //copying line to tmp
	tmp = remove_inspaces(tmp);
	if((word = strtok_r(tmp," ",&tmp)) != NULL && !is_empty(tmp)){//checking if there's an extra text after a space
		is_error = 1;
		return 1;
	}	
	return 0;
}

//This function checks if a line contains a comma in the end of a line. it gets the line as a parameter and returns 1 if there's a comma, or 0 else
int check_illegal_comma(char *line){
	char *tmp;
	tmp = strdup(line); //copying the line to tmp
	remove_spaces(tmp); //removing all spaces
	if(tmp[strlen(tmp)-1] == ','){ //checking if there's a comma in the end of the line
		is_error = 1;
		return 1;
	}
	return 0;
}

//This function checks if the label was missing a colon by checking if the opcode is a label and first operand contains an opcode. It gets the first operand(par) and the opcode(op) as a parameter, and returns 1 if there was found that there's missing a colon in the label, and 0 else.
int check_missing_colon(char *par, char *op){
	char *tmp_line,*tmp;
	tmp_line = strdup(par);
	tmp_line = remove_inspaces(tmp_line);
	tmp = (check_space_type(tmp_line) == '\t') ? strtok_r(tmp_line,"\t",&tmp_line) : strtok_r(tmp_line," ",&tmp_line);
	if(find_op(op) == MISSING && find_op(tmp) != MISSING){
		printf("[line %d] ERROR: label must end with a colon\n",line_cnt);
		is_error = 1;
		return 1;
	}
	return 0;
}
