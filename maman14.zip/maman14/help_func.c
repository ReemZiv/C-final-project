//This file contain functions to help the program in different ways like formatting bases(from decimal to binary or base64), finding the type of an operand and more
#include "assembler.h"
extern int is_error,is_all_error;
extern int line_cnt;

//This function removes all the spaces from a string. It gets a string as a parameter(line) and returns void.
void remove_spaces(char *line) {
    char *tmp = line;
    do {
        while (isspace(*tmp)) {
            ++tmp;
        }
    } while (*line++ = *tmp++);
}

//This function removes all initial spaces from a string. It gets a string as a parameter(line) and returns void.
char *remove_inspaces(char *line){
	while(isspace(*line)) //removing initial spaces
		line++;
	return line;
}

//This function checks what is the first space indicated(' ' or tab) in a line so the program can use strtok_r on both of them. It gets the line as a parameter and return the first space as a char that was indicated
char check_space_type(char *line){
	while(!isspace(*line))
		line++;
	return *line;
}

//This function checks if a string in empty. It gets a string as a parameter(line) and returns 1 if it is empty and 0 if it isn't.
int is_empty(char *line){
	char *tmp = strdup(line);
	remove_spaces(tmp);
	return (tmp[0] == '\0' || tmp[0] == '\n') ? 1 : 0;
}

//This function returns a string of the name of an operand type. It gets the operand type as a number and returns a string of the name of the operand type.
char *num_to_type(int operand_type){
	if(operand_type == IM_ADDRESS)
		return "immediate";
	else if (operand_type == DIRECT_ADDRESS)
		return "direct";
	return "register";
}

//This function returns how many operands an opcode should have. It gets the opcode as an int.
int count_par(int op){
	if((op >= find_op("mov") && op <= find_op("sub")) || op == find_op("lea"))
		return TWO_PAR;
	else if(op == find_op("rts") || op == find_op("stop"))
		return 0;
	return 1;
}

//This function counts how many operands were inserted
int count_input_par(AST *par1, AST *par2){
	if(par1->tag == OPERAND_1 && par2->tag == OPERAND_2){
		return TWO_PAR;
	}
	else if(par1->tag == OPERAND_1 && par2->tag != OPERAND_2){
		return 1;
	}
	return 0;
}

//This function applies the binary code of a number(num) from the n-th bit on the binary code of another number inserted(b) and returns b after its changes.
int bin_nset(int b, int num, int n){
	for(n; num != 0 && n < BIT_SIZE; n++){ //This for loop goes on every bit from the n-th bit till the 12-th bit and changes the bit of b to the bit of num
		(1 & num) ? BIN_SET(b,n) : 0;
		num >>= 1;
	}
	return b;
}

//This function indicates what is the type of the the operand. It gets the operand as a parameter(par) and returns the number of the type of the operand(1 - immediate address, 3 - direct address, 5 - register address
int find_par(char *par){
	if(atoi(par) != 0 || strcmp(par, "0") == 0) //checking if it's a number
		return IM_ADDRESS;
	if(strncmp(par,"@r",START_LEN_OF_REGISTER_OPERAND) == 0 && isdigit(par[REG_NUM_INDEX])){ //checking if it's a register
		remove_spaces(par);
		//checking the validity of the register
		if(strlen(par) != REGISTER_OPERAND_LEN){ //checking for extra text
			printf("[line %d] ERROR: extra line after end of command\n",line_cnt);
			is_error = 1;
			return MISSING;
		}
		if(par[REG_NUM_INDEX] - '0' > MAX_REGISTER || par[REG_NUM_INDEX] - '0' < 1){ //checking that register number is between 1-7
			printf("[line %d] ERROR: register number must be between 1 to 7 \n", line_cnt);
			is_error = 1;
			return MISSING;
		}
		return REG_ADDRESS;
	}
	
	if(par[0] == 'r' && isdigit(par[1]) && par[1] - '0' <= MAX_REGISTER && par[1] - '0' >= 1 && strlen(par) == REGISTER_OPERAND_LEN - 1) //checking if register was written without at sign(@), and releasing a warning(not an error) in first go and in second go to the user and the program is addressing it as a label
		printf("[line %d] WARNING: if the operand was meant to be register, register number must start with at sign(@). The program adresses %s as a label.\n",line_cnt,par);
		
	//the only option left is direct address
	if(check_label(par) == 0){
		is_error = 1;
		return MISSING;
	}
	return DIRECT_ADDRESS; 
}

//This function handles in case a line had an error. It gets the error_arr(that holds indicates of lines that had errors) and the AST of the line. it returns the error_arr after editing it
char *handle_error(char *error_arr, AST *tree){
		is_all_error = 1; //changing global is_all_error to 1 to tell the program this file has errors and it can't produce output files
		error_arr[line_cnt] = '1'; //editing the error_arr in the index of line_cnt to 1 to tell this line had an error
		if(tree->tag == LABEL) update_error(tree->data.LABEL.label); //if there was a symbol declaration, we change it's value to 0
		return error_arr; 
}

//This function builds the binary code of the operands. It gets the binary code to apply on, the type of the operand as an integer, the operand itself as a string, and integer called index that represents the index we want to apply binary code of register(so we can apply it on cases of two register operands).
int handle_par(int binary_code, int par_code, char *operand, int index){
	int reg_num;
	
	switch(par_code){
		case IM_ADDRESS: //if it's an operand of immediate address
			return bin_nset(binary_code,atoi(operand),2); //applying the binary code of the number from the second 
		case REG_ADDRESS: //if it's a register
			reg_num = operand[2]-'0'; //extracting the number of the register to an integer 
			return bin_nset(binary_code,reg_num,index); //applying the binary code of the register number in the index that was entered(source place or destination place)
		case DIRECT_ADDRESS: //if it's a label we return 0 and completet it's binary code in second go
			return 0;
	}
}

//This function gets a number, converts it to base64 and saves it's result in a string. It gets the number as an int called num and the string it saves the result in as a string called arr and returns it.
char *binary_to_base64(int num, char *arr) { // converts a memory word to base64
	const char base64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; //This string contains every character in the base64 format and every index holds the representation of the index in base64.
    int part1, part2, n;
    char p1, p2;
    char *result;
    
    //formatting to base64 takes every 6 bits of the number and convert them to a character in base64
    part2 = num >> 6; //gets the number's last 6 bits(from right to left, bits 6-11)
    p2 = base64[part2]; //formatting this 6 bits to base64 
    //getting the number's first 6 bits(from right to left, bits 0-5)
    n = part2 << 6;
    part1 = n ^ num;
    p1 = base64[part1]; //formatting this 6 bits to base64 
    result = arr; //applying result to arr so we can change the values each time and return it
    *result = p2; //changing the first character to the base64 format first character
    *(++result) = p1; //changing the second character to the base64 format second character
    *(++result) = '\0'; //ending the string with \0
    return arr; //returning the completed base64 format
}

//This functio frees all the allocated memory of the attributes of the AST of the line. It gets a pointer to each node as arguments.
void free_memory(AST *tree, AST *op_node, AST *par1, AST *par2){
	par2 = NULL;
	free(par2);
	par1 = NULL;
	free(par1);
	free(op_node);
	free(tree);
}
