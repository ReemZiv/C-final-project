//This file represents the memory image of our virtual machine.
#include "assembler.h"

//initializing global variables
int *inst, *data_arr; //inst - instructions binary code array, data_arr - data binary code array
extern int line_cnt;

//This function initializes the arrays.
void memory_map(){
	inst = (int *) malloc(1);
	data_arr = (int *) malloc(1);
}

//This function inserts an instruction binary code to the instructions array. It gets the instruct binary code(as an int) and IC(which we use as the next index of the available place in the array) as parameters.
void insert_inst(int instruct, int IC){ 
	inst = (int *) realloc(inst, (IC+1) * sizeof(int));
	inst[IC] = instruct;
}

//This function inserts an data binary code to the data array. It gets the data binary code(as an int) and DC(which we use as the next index of the available place in the array) as parameters.
void insert_data(int data_val, int DC){
	data_arr = (int *) realloc(data_arr, (DC+1) * sizeof(int));
	data_arr[DC] = data_val;
}

//This function changes a value of an instruction binary code in the instructions array. It gets the instruct binary code(as an int) and the index of the value we want to change
void change_inst(int instruct, int index){
	inst[index] = instruct;
}

//This function creates the object file. It gets the file name, IC and DC as parameters.
void create_object(char *name, int IC, int DC){
	//initializing
    FILE* file_ob;
    char b64[BASE64_LENGTH] = "  ",new_name[FILE_NAME_MAX]; 
    char* result;
    
    //creating the file
    strcpy(new_name,name);
    strcat(new_name,".ob");
    file_ob = fopen(new_name, "w"); // opening the file in write mode
    if (file_ob == NULL) {  //c hecking if the file was opened successfully
        printf("[line %d] ERROR: Failed to open object file for writing.\n",line_cnt);
        return;
    }
    
    //Writing the first part of the object: IC and DC(both in decimal base)
    fprintf(file_ob, "%d  %d\n", IC, DC);
    
    //Writing the instructions to the file in base64
    int i, m;
    for(i=0; i < IC; i++)
    {
    	result = binary_to_base64(inst[i], b64);
    	fprintf(file_ob, "%s\n", result);
    }
    
    //Writing the data to the file in base64
    for(m=0; m < DC; m++)
    {
    	result = binary_to_base64(data_arr[m], b64);
    	fprintf(file_ob, "%s\n", result);
    }
    
	fclose(file_ob);
}

void free_memory_map(){
	free(inst);
	free(data_arr);
}
