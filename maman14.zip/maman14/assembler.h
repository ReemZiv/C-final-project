#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

//CONSTANTS
#define LINE_MAX 81 //maximum length of a line including \n
#define BIGGER_THAN_LINE_MAX 100 //max len of line is 80 but we are allocating the string of the line to check if the length of the line is larger than 80.
#define LABEL_MAX_LEN 31 //maximum length of a label
#define MISSING -1 //used in functions to alert errors
#define OP2_MISSING -2 //indicates second operand isn't valid according to the operands the opcode should've
#define OP_INDEX 5 //the opcode index in the binary code of the first word
#define DES_INDEX 2 //the destination operand index in the binary code of the first word
#define SOURCE_INDEX 9 //the source operand index in the binary code of the first word
#define IM_ADDRESS 1 //code of immediate address of operand
#define DIRECT_ADDRESS 3 //code of direct address of operand
#define REG_ADDRESS 5 //code of register address of operand
#define REG_NUM_INDEX 2 //index of the number in registers
#define DES_REG_INDEX 2 //index in the binary code of a register that is a destination operand in a command which both of the operands are registers
#define SOURCE_REG_INDEX 7 //index in the binary code of a register that is a source operand in a command which both of the operands are registers
#define TWO_PAR 2 //two operands
#define RELOCATABLE 2 //code of relocatable in ARE in the binary code of the first word
#define FIRST_ADDRESS 100 //first address number in decimal
#define BIT_SIZE 12 //number of bits in each binary number of instruction or data
#define BASE64_LENGTH 3 //length of a base64 format string(including \0)
#define FILE_NAME_MAX 20 //maximum file name
#define OP_COUNT 16 //count of opcodes not including data instructions
#define MAX_REGISTER 7 //maximum number of register
#define OPCODES_WITH_PARS_CNT 14 //number of opcodes with operands
#define SOURCE_AND_DEST_OPERANDS 2 //some opcodes can have both source and destination operands, so 2 is the maximum operands
#define MAX_TYPE_OPERANDS 3 //maximum type of operands(immediate,direct,register)
#define REGISTER_OPERAND_LEN 3 //length of a register operand
#define START_LEN_OF_REGISTER_OPERAND 2 //length of the beginning of each register operand("@r")

//macros
#define BIN_SET(B,I) (B) |= 1 << (I)  //changes the bit of a number(b) in index I

//enum
enum {
	data,
	external,
	code,
	entry,
} type; //types of labels


//structures 
typedef struct mcro{ //dynamic list of macros
	char *name;
	char *content;
	struct mcro *next;
} mcro;

typedef struct sym_tab{ //dynamic list of symbols
	char *symbol;
	int value;
	int type;
	struct sym_tab *next;
} sym_tab;

typedef struct AST AST; //abstract syntax tree

struct AST{
  	enum {
    	LABEL,
    	OPCODE,
    	OPERAND_1,
    	OPERAND_2,
  	} tag; //tag - indicated the type of the node
  	union {
    	struct LABEL { char *label; AST *opcode;} LABEL;
    	struct OPCODE { char *opcode; AST *operand_1; AST *operand_2; } OPCODE;
    	char *op1;
    	char *op2;
  	} data; //contains the data the node holds
};

//pre_processor.c
int pre_processor(FILE *,char*);

//help_func.c
void remove_spaces(char*);
char *remove_inspaces(char*);
char check_space_type(char *);
int is_empty(char*);
char *num_to_type(int);
int count_par(int);
int count_input_par(AST *, AST *);
int bin_nset(int, int, int);
int find_par(char *);
char *handle_error(char *, AST *);
char *binary_to_base64(int, char*);
void free_memory(AST *, AST *, AST *, AST *);

//analyze_input.c
AST *analyze_input(char*, AST *);

//check_errors.c
int check_label(char *);
int check_extra(char *);
int check_illegal_comma(char *);
int check_missing_colon(char *, char *);

//handle_command.c
void handle_extern(char *);
int handle_data(char *, int);
int handle_string(char *, int);
void handle_op(int, AST *, int, int);
int handle_par(int,int, char *, int);
void complete_op(AST *, AST *, int, int);

//symbols_table.c
void symbols_table();
void insert_sym(char *, int, int);
void insert_extern(char *, int);
void update_sym(int);
void update_entry(char *);
void update_error(char *);
int find_sym(char *);
void create_extern(char *);
void create_entry(char *);
void free_sym();

//memory_map.c
void memory_map();
void insert_inst(int, int);
void insert_data(int, int);
void change_inst(int, int);
void create_object(char *,int IC, int DC);
void free_memory_map();

//const_tables.c
int find_op(char *);
int check_par(int, int, int, int);
int check_element(int[], int);

//first_go.c
void first_go(FILE *); 

//second_go.c
void second_go(FILE *,char *);
