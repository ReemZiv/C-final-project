#include "assembler.h"

//This pre_processor function looking for macros declarations and inserting their content to the macros table which is represented using a linked list, also if the program identifies a macro in the file, it copies its content and outputting a new spread macros file which contains the file without macros declarations or initalizations
int pre_processor(FILE *ass,char *file_name){
	//initializations
	char *line = (char *)(malloc(BIGGER_THAN_LINE_MAX)), *tmp_line = (char *)(malloc(LINE_MAX)), *copy_tmp_line = (char *) (malloc(LINE_MAX));
	char new_name[FILE_NAME_MAX];
	char *mcro_name;
	int is_mcro = 0, is_mcro_found = 0,is_mcro_error=0;
	int line_macro_cnt = 0;
	mcro *first = (mcro *) malloc(sizeof(mcro));
	mcro *tmp, *curr = first;
	
	first->next = NULL;
	strcpy(new_name,file_name);
	strcat(new_name,".am");
	FILE *spread_file = fopen(new_name,"w");

	while(fgets(line,BIGGER_THAN_LINE_MAX,ass) != NULL){ //Reading from the file until EOF
		line_macro_cnt++;
		tmp_line = strdup(line);
		
		if(strlen(line) > ((line[strlen(line)-1] == '\n') ? LINE_MAX : LINE_MAX-1)){
			fputs(line,spread_file);
			continue;
		}
		
		if(is_empty(tmp_line) || tmp_line[0] == ';'){
			fputs(line,spread_file);
			continue;
		}

		tmp_line = remove_inspaces(tmp_line);
		mcro_name = strtok_r(tmp_line, " ",&tmp_line); //extracting the first word of the line

		//Next while loop checkes if the first word of the sentence is a macro name from the macros table
		tmp = first;
		remove_spaces(mcro_name);
		while(tmp->next != NULL && is_mcro == 0){
			if(strcmp(tmp->name,mcro_name) == 0){ //If the first word matches a macro name
				fputs(tmp->content,spread_file); //writing its content to the macro spread file 
				is_mcro_found = 1; //signalling a macro name was foiund
				break;
			}
			tmp = tmp->next; //moving to the next macro in the macros table
		}

		if(is_mcro_found == 1){
			is_mcro_found = 0;
			continue;
		}
		
		//This next few lines check if a macro was declared and if so, turning up the is_mcro flag and inserting its name to the macros table
		copy_tmp_line = strdup(tmp_line);
		remove_spaces(tmp_line);
		if(strcmp(mcro_name,"mcro") == 0){
			if(find_op(tmp_line) != MISSING || strcmp(tmp_line,".data") == 0 || strcmp(tmp_line,".string") == 0 || strcmp(tmp_line,".extern") == 0 || strcmp(tmp_line,".entry") == 0){
				printf("[line %d] ERROR: macro name can't be an instruction or data opcode\n",line_macro_cnt);
				is_mcro_error = 1;
				continue;
			}
			if(check_extra(copy_tmp_line)){
				printf("[line %d] ERROR: extra text after definition of macro\n",line_macro_cnt);
				is_mcro_error = 1;
				continue;
			} 
			is_mcro = 1;
			curr->name = (char *) malloc(strlen(tmp_line)+1);
			strcpy(curr->name,tmp_line);
			continue;
		}
		
		//This next few lines check if an endmcro was declared, if so,the program turnsn off the is_mcro flag and creating a new NULL mcro
		if(strcmp(mcro_name,"endmcro") == 0){
			if(!is_empty(tmp_line)){ //checking for extra text
				printf("[line %d] ERROR: extra text after end of macro\n",line_macro_cnt);
				is_mcro_error = 1;
			}
			
			if(is_mcro == 0) //checking if in the definition of the macro there was an error
				continue;
				
			is_mcro = 0;
			tmp = (mcro *) malloc(sizeof(mcro));
			curr->next = tmp;
			curr = curr->next;
			continue;
		}
		
		//This next few lines check if the program is currently in mcro, and if so, it copies the content of the line to the mcro content
		if(is_mcro == 1){ //if is_mcro flag is up, it means the program is in a macro initalization
			if(curr->content == NULL)
				curr->content = (char *) malloc(LINE_MAX);
			curr->content = (char *) realloc(curr->content,sizeof(curr->content)/sizeof(char) + LINE_MAX); //reallocing space for the new content of the line
			strcat(curr->content,line); //coping the content of the line to the macro content
			continue;
		}
		
		fputs(line,spread_file); //If nothing related to macros happened, the program copies the line as it is to the spread macros file
		
	}
	(is_mcro_error) ? remove(new_name) : fclose(spread_file);  //if there was an error in the spreading of the macros, we delete the expanded source file(.am file)
	
	//freeing the macro dynamic list
	tmp = first;
	while(tmp->next != NULL){
		curr = tmp;
		tmp = tmp->next; //moving to the next macro in the macros table
		free(curr->name);
		free(curr->content);
		free(curr);
	}
	
	return !is_mcro_error;
}
