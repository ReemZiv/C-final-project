//This program simulates an assembler that checks the syntax validity of an assembly program and translates it to machine code

//This file contains the main function, which gets the name of the files we want the program to run on from the command line and runs the whole algorithm - pre processor, first go and second go on the files
#include "assembler.h"

main(int argc, char *argv[]){
	char file_name[FILE_NAME_MAX];
	FILE *tmp_file;
	for(int i = 1; i < argc; i++){ //going on every parameter in the command line
		//creating the name of the file we look for
		strcpy(file_name,argv[i]);
		strcat(file_name,".as");
		printf("\nRunning %s\n",file_name);
		//trying to open the assembly file
		if((tmp_file = fopen(file_name,"r")) == NULL){
			printf("ERROR: file doesn't exist\n");
			return 0;
		}
		//running the pre processor on the file, if there are no errors, it moves on
		if(!pre_processor(tmp_file,argv[i]))
			return 0;
		//creating the name of the expanded source file
		strcpy(file_name,argv[i]);
		strcat(file_name,".am");
		//trying to open the expanded source file the pre processor created
		if((tmp_file = fopen(file_name,"r")) != NULL){
			first_go(tmp_file); //running the first go
			tmp_file = fopen(file_name,"r");
			second_go(tmp_file,argv[i]); //running the second go
		}
	}
}
